import React, { useEffect, useMemo, useState } from 'react'
import { createClient } from '@supabase/supabase-js'
import { Store, LayoutDashboard, ShoppingCart, ChefHat, Package, BarChart3, Plus, Minus, Trash2, Search, LogOut, Wifi, WifiOff, RefreshCw, ArrowLeftRight, X } from 'lucide-react'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY
const supabase = supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey) : null
const money = n => new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:2}).format(Number(n||0))
const starterBranches = [
  {id:'b1',name:'Branch 1',location:'Add branch address'},
  {id:'b2',name:'Branch 2',location:'Add branch address'},
  {id:'b3',name:'Branch 3',location:'Add branch address'}
]
const starterProducts = [
  {id:'p1',name:'Classic Burger',category:'Burgers',price:129,available:true},
  {id:'p2',name:'Cheese Burger',category:'Burgers',price:159,available:true},
  {id:'p3',name:'French Fries',category:'Sides',price:89,available:true},
  {id:'p4',name:'Veg Wrap',category:'Wraps',price:119,available:true},
  {id:'p5',name:'Cold Coffee',category:'Drinks',price:99,available:true},
  {id:'p6',name:'Paneer Roll',category:'Rolls',price:139,available:true}
]
const seed = {branches:starterBranches,products:starterProducts,orders:[]}
function loadLocal(){try{return JSON.parse(localStorage.getItem('angrybox-data'))||seed}catch{return seed}}
function saveLocal(data){localStorage.setItem('angrybox-data',JSON.stringify(data))}
export default function App(){
  const [data,setData]=useState(loadLocal)
  const [branchId,setBranchId]=useState('b1')
  const [page,setPage]=useState('dashboard')
  const [cart,setCart]=useState([])
  const [search,setSearch]=useState('')
  const [category,setCategory]=useState('All')
  const [notice,setNotice]=useState('')
  const [busy,setBusy]=useState(false)
  const [newBranch,setNewBranch]=useState('')
  const [newProduct,setNewProduct]=useState({name:'',category:'Mains',price:''})
  const [showBranch,setShowBranch]=useState(false)
  const [showProduct,setShowProduct]=useState(false)
  const [cloud,setCloud]=useState(false)
  const branch=data.branches.find(b=>b.id===branchId)||data.branches[0]
  const orders=data.orders.filter(o=>o.branch_id===branchId)
  const today=new Date().toISOString().slice(0,10)
  const todayOrders=orders.filter(o=>o.created_at.slice(0,10)===today)
  const todaySales=todayOrders.reduce((s,o)=>s+Number(o.total),0)
  const categories=['All',...new Set(data.products.map(p=>p.category))]
  const shownProducts=data.products.filter(p=>p.available && (category==='All'||p.category===category) && p.name.toLowerCase().includes(search.toLowerCase()))
  const allSales=data.orders.reduce((s,o)=>s+Number(o.total),0)
  useEffect(()=>{saveLocal(data)},[data])
  useEffect(()=>{if(supabase) loadCloud()},[])
  async function loadCloud(){
    setBusy(true)
    try{
      const [b,p,o]=await Promise.all([
        supabase.from('branches').select('*').order('name'),
        supabase.from('products').select('*').order('name'),
        supabase.from('orders').select('*, order_items(*)').order('created_at',{ascending:false}).limit(500)
      ])
      if(b.error) throw b.error
      if(p.error) throw p.error
      if(o.error) throw o.error
      setData({branches:b.data||[],products:p.data||[],orders:(o.data||[]).map(x=>({...x,items:x.order_items||[]}))})
      if(b.data?.length && !b.data.some(x=>x.id===branchId)) setBranchId(b.data[0].id)
      setCloud(true);setNotice('Connected to online database')
    }catch(e){setNotice('Cloud connection: '+e.message+' — showing local demo data')}
    finally{setBusy(false)}
  }
  async function persistOrder(order){
    if(!supabase){setData(d=>({...d,orders:[order,...d.orders]}));return}
    const {data:created,error}=await supabase.from('orders').insert({branch_id:order.branch_id,total:order.total,status:'new'}).select().single()
    if(error) throw error
    const rows=order.items.map(i=>({order_id:created.id,product_id:i.id,product_name:i.name,quantity:i.qty,unit_price:i.price,line_total:i.price*i.qty}))
    const {error:itemError}=await supabase.from('order_items').insert(rows)
    if(itemError) throw itemError
    await loadCloud()
  }
  async function checkout(){
    if(!cart.length)return
    const order={id:'local-'+Date.now(),branch_id:branchId,total:cart.reduce((s,i)=>s+i.price*i.qty,0),status:'new',created_at:new Date().toISOString(),items:cart}
    try{await persistOrder(order);setCart([]);setPage('kitchen');setNotice('Order sent to kitchen')}
    catch(e){setNotice('Could not save order: '+e.message)}
  }
  function addCart(p){setCart(c=>{const x=c.find(i=>i.id===p.id);return x?c.map(i=>i.id===p.id?{...i,qty:i.qty+1}:i):[...c,{...p,qty:1}]})}
  function changeQty(id,delta){setCart(c=>c.map(i=>i.id===id?{...i,qty:i.qty+delta}:i).filter(i=>i.qty>0))}
  async function changeStatus(order,status){
    if(supabase && !String(order.id).startsWith('local-')){const {error}=await supabase.from('orders').update({status}).eq('id',order.id);if(error){setNotice(error.message);return}await loadCloud()}
    else setData(d=>({...d,orders:d.orders.map(o=>o.id===order.id?{...o,status}:o)}))
  }
  async function addBranch(){
    if(!newBranch.trim())return
    const row={name:newBranch.trim(),location:'Add address'}
    if(supabase){const {data:created,error}=await supabase.from('branches').insert(row).select().single();if(error){setNotice(error.message);return}setData(d=>({...d,branches:[...d.branches,created]}));setBranchId(created.id)}
    else {const created={...row,id:'b'+Date.now()};setData(d=>({...d,branches:[...d.branches,created]}));setBranchId(created.id)}
    setNewBranch('');setShowBranch(false)
  }
  async function addProduct(){
    if(!newProduct.name.trim()||Number(newProduct.price)<=0)return
    const row={name:newProduct.name.trim(),category:newProduct.category.trim()||'Mains',price:Number(newProduct.price),available:true}
    if(supabase){const {data:created,error}=await supabase.from('products').insert(row).select().single();if(error){setNotice(error.message);return}setData(d=>({...d,products:[...d.products,created]}))}
    else setData(d=>({...d,products:[...d.products,{...row,id:'p'+Date.now()}]}))
    setNewProduct({name:'',category:'Mains',price:''});setShowProduct(false)
  }
  const nav=[['dashboard','Overview',LayoutDashboard],['billing','New Bill',ShoppingCart],['kitchen','Kitchen',ChefHat],['menu','Menu & Items',Package],['reports','Reports',BarChart3]]
  return <div className="app">
    <aside className="sidebar"><div className="brand"><div className="brand-mark">AB</div><div><b>ANGRY BOX</b><small>RESTAURANT POS</small></div></div>
      <div className="side-label">WORKSPACE</div>{nav.map(([id,label,Icon])=><button key={id} className={'nav '+(page===id?'active':'')} onClick={()=>setPage(id)}><Icon size={18}/>{label}</button>)}
      <div className="side-bottom"><div className="connection">{cloud?<Wifi size={15}/>:<WifiOff size={15}/>}<span>{cloud?'Online database':'Local demo mode'}</span></div><small>ANGRY BOX • v1.0</small></div>
    </aside>
    <main className="main">
      <header className="topbar"><div><div className="eyebrow">MULTI-BRANCH MANAGEMENT</div><h1>{nav.find(n=>n[0]===page)?.[1]||'Overview'}</h1></div><div className="top-actions"><button className="icon-btn" onClick={loadCloud} title="Refresh"><RefreshCw size={17}/></button><div className="branch-picker"><Store size={17}/><select value={branchId||''} onChange={e=>setBranchId(e.target.value)}>{data.branches.map(b=><option key={b.id} value={b.id}>{b.name}</option>)}</select></div><button className="btn dark small" onClick={()=>setShowBranch(true)}><Plus size={15}/> Add branch</button></div></header>
      {notice&&<div className="notice" onClick={()=>setNotice('')}>{notice}<button><X size={14}/></button></div>}
      {page==='dashboard'&&<><section className="welcome"><div><span className="pill">OWNER VIEW</span><h2>Good to see you.</h2><p>Here’s what’s happening at {branch?.name||'your branch'} today.</p></div><div className="welcome-icon"><Store size={36}/></div></section>
        <section className="stats"><Stat label="Today's sales" value={money(todaySales)} note={`${todayOrders.length} orders today`} icon={BarChart3}/><Stat label="Today's orders" value={todayOrders.length} note="Selected branch" icon={ShoppingCart}/><Stat label="All-branch sales" value={money(allSales)} note="Across all branches" icon={Store}/><Stat label="Branches" value={data.branches.length} note="Locations in your group" icon={Package}/></section>
        <section className="panel"><div className="panel-head"><div><h3>Branch performance</h3><p>Sales recorded in this browser or online database</p></div><button className="text-btn" onClick={()=>setPage('reports')}>View reports →</button></div><div className="branch-list">{data.branches.map(b=>{const list=data.orders.filter(o=>o.branch_id===b.id&&o.created_at.slice(0,10)===today);const total=list.reduce((s,o)=>s+Number(o.total),0);return <div className="branch-row" key={b.id}><div className="branch-avatar"><Store size={18}/></div><div className="branch-name"><b>{b.name}</b><small>{b.location||'Location not set'}</small></div><div className="branch-metric"><b>{money(total)}</b><small>{list.length} orders</small></div><button className="outline-btn" onClick={()=>{setBranchId(b.id);setPage('billing')}}>Open POS</button></div>})}</div></section>
      </>}
      {page==='billing'&&<div className="billing-layout"><section className="panel products-panel"><div className="panel-head"><div><h3>Menu</h3><p>Select items to add to the current order</p></div><span className="pill">{branch?.name}</span></div><div className="search"><Search size={17}/><input placeholder="Search menu items..." value={search} onChange={e=>setSearch(e.target.value)}/></div><div className="chips">{categories.map(c=><button key={c} className={'chip '+(category===c?'selected':'')} onClick={()=>setCategory(c)}>{c}</button>)}</div><div className="product-grid">{shownProducts.map(p=><button className="product-card" key={p.id} onClick={()=>addCart(p)}><span className="product-symbol">＋</span><b>{p.name}</b><small>{p.category}</small><strong>{money(p.price)}</strong></button>)}</div></section>
        <section className="panel cart-panel"><div className="panel-head"><div><h3>Current order</h3><p>{branch?.name}</p></div><span className="pill">{cart.reduce((s,i)=>s+i.qty,0)} items</span></div>{!cart.length?<div className="empty"><ShoppingCart size={30}/><b>Your order is empty</b><span>Tap a menu item to add it</span></div>:<div className="cart-items">{cart.map(i=><div className="cart-item" key={i.id}><div className="cart-name"><b>{i.name}</b><small>{money(i.price)} each</small></div><div className="qty"><button onClick={()=>changeQty(i.id,-1)}><Minus size={13}/></button><b>{i.qty}</b><button onClick={()=>changeQty(i.id,1)}><Plus size={13}/></button></div><strong>{money(i.price*i.qty)}</strong><button className="remove" onClick={()=>changeQty(i.id,-i.qty)}><Trash2 size={15}/></button></div>)}</div>}<div className="cart-footer"><div className="total-line"><span>Subtotal</span><b>{money(cart.reduce((s,i)=>s+i.price*i.qty,0))}</b></div><div className="total-line grand"><span>Total</span><b>{money(cart.reduce((s,i)=>s+i.price*i.qty,0))}</b></div><button className="btn primary full" disabled={!cart.length} onClick={checkout}>Send order to kitchen</button><small className="muted center">Taxes and payment collection need configuring before live use.</small></div></section></div>}
      {page==='kitchen'&&<section className="panel"><div className="panel-head"><div><h3>Kitchen display</h3><p>Incoming orders for {branch?.name}</p></div><span className="pill">{orders.filter(o=>o.status!=='completed').length} active</span></div><div className="kitchen-grid">{orders.filter(o=>o.status!=='completed').map(o=><div className="kitchen-card" key={o.id}><div className="kitchen-top"><b>Order #{String(o.id).slice(-5)}</b><span className={'status '+o.status}>{o.status}</span></div><small>{new Date(o.created_at).toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'})}</small><div className="kitchen-items">{(o.items||[]).map((i,n)=><div key={n}><b>{i.qty||i.quantity} ×</b> {i.name||i.product_name}</div>)}</div><div className="kitchen-bottom"><b>{money(o.total)}</b>{o.status==='new'?<button className="btn primary small" onClick={()=>changeStatus(o,'preparing')}>Start preparing</button>:<button className="btn dark small" onClick={()=>changeStatus(o,'completed')}>Mark completed</button>}</div></div>)}</div>{orders.filter(o=>o.status!=='completed').length===0&&<div className="empty"><ChefHat size={32}/><b>No active orders</b><span>New bills will appear here.</span></div>}</section>}
      {page==='menu'&&<section className="panel"><div className="panel-head"><div><h3>Menu & items</h3><p>Manage products available for billing</p></div><button className="btn dark small" onClick={()=>setShowProduct(true)}><Plus size={15}/> Add item</button></div><div className="table-wrap"><table><thead><tr><th>ITEM</th><th>CATEGORY</th><th>PRICE</th><th>STATUS</th></tr></thead><tbody>{data.products.map(p=><tr key={p.id}><td><b>{p.name}</b></td><td>{p.category}</td><td>{money(p.price)}</td><td><span className="status completed">Available</span></td></tr>)}</tbody></table></div></section>}
      {page==='reports'&&<><section className="stats"><Stat label="Total sales" value={money(allSales)} note="All recorded orders" icon={BarChart3}/><Stat label="Total orders" value={data.orders.length} note="All branches" icon={ShoppingCart}/><Stat label="Average order" value={money(data.orders.length?allSales/data.orders.length:0)} note="Across all recorded orders" icon={Package}/><Stat label="Branches" value={data.branches.length} note="Currently configured" icon={Store}/></section><section className="panel"><div className="panel-head"><div><h3>Sales by branch</h3><p>All recorded orders</p></div></div><div className="branch-list">{data.branches.map(b=>{const list=data.orders.filter(o=>o.branch_id===b.id);return <div className="branch-row" key={b.id}><div className="branch-avatar"><BarChart3 size={18}/></div><div className="branch-name"><b>{b.name}</b><small>{list.length} orders</small></div><div className="branch-metric"><b>{money(list.reduce((s,o)=>s+Number(o.total),0))}</b><small>Gross sales</small></div></div>})}</div></section></>}
    </main>
    {(showBranch||showProduct)&&<div className="modal-backdrop" onClick={()=>{setShowBranch(false);setShowProduct(false)}}><div className="modal" onClick={e=>e.stopPropagation()}><div className="modal-head"><h3>{showBranch?'Add a branch':'Add menu item'}</h3><button className="icon-btn" onClick={()=>{setShowBranch(false);setShowProduct(false)}}><X size={18}/></button></div>{showBranch?<><label>Branch name</label><input className="field" value={newBranch} onChange={e=>setNewBranch(e.target.value)} placeholder="e.g. Angry Box Model Town"/><button className="btn primary full" onClick={addBranch}>Create branch</button></>:<><label>Item name</label><input className="field" value={newProduct.name} onChange={e=>setNewProduct({...newProduct,name:e.target.value})} placeholder="e.g. Spicy Burger"/><label>Category</label><input className="field" value={newProduct.category} onChange={e=>setNewProduct({...newProduct,category:e.target.value})}/><label>Price (INR)</label><input className="field" type="number" min="1" value={newProduct.price} onChange={e=>setNewProduct({...newProduct,price:e.target.value})} placeholder="149"/><button className="btn primary full" onClick={addProduct}>Save item</button></>}</div></div>}
  </div>
}
function Stat({label,value,note,icon:Icon}){return <div className="stat"><div className="stat-icon"><Icon size={19}/></div><small>{label}</small><strong>{value}</strong><span>{note}</span></div>}