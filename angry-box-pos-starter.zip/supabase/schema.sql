-- ANGRY BOX POS: starter database schema
-- Run this in Supabase SQL Editor only after creating a new Supabase project.
create extension if not exists pgcrypto;

create table if not exists public.branches (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  location text default '',
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null default 'Mains',
  price numeric(10,2) not null check (price >= 0),
  available boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  branch_id uuid not null references public.branches(id),
  total numeric(10,2) not null check (total >= 0),
  status text not null default 'new' check (status in ('new','preparing','completed','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id),
  product_name text not null,
  quantity integer not null check (quantity > 0),
  unit_price numeric(10,2) not null,
  line_total numeric(10,2) not null
);

-- IMPORTANT: This starter has RLS enabled but intentionally no public policies.
-- Before connecting a live POS, add Supabase Auth and role/branch membership policies.
-- Do NOT disable RLS or expose the service_role key in the website.
alter table public.branches enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

-- Seed three initial branches. Edit names/addresses after import.
insert into public.branches(name, location)
select 'Branch 1','Add address' where not exists (select 1 from public.branches);
insert into public.branches(name, location)
select 'Branch 2','Add address' where (select count(*) from public.branches) < 2;
insert into public.branches(name, location)
select 'Branch 3','Add address' where (select count(*) from public.branches) < 3;

-- Seed example menu items.
insert into public.products(name,category,price)
select v.name,v.category,v.price
from (values
 ('Classic Burger','Burgers',129.00),
 ('Cheese Burger','Burgers',159.00),
 ('French Fries','Sides',89.00),
 ('Veg Wrap','Wraps',119.00),
 ('Cold Coffee','Drinks',99.00),
 ('Paneer Roll','Rolls',139.00)
) as v(name,category,price)
where not exists (select 1 from public.products);